Ziyu Qiu
COSI 131a
PA3
Dec.5 2016

My program generally takes around 60 seconds to pass all the tests.

For BitWise, I simply follow the instruction of each method and use the bitwise operaters, there's not much to say about.


// Index     0  1  2  3  4  5  6  7  8  9  10           11                            12
// LEVEL0   [1][1][1][1][1][1][1][1][1][1][↓]          [↓]                           [↓]
// LEVEL1   [*][*][*][*][*][*][*][*][*][*][[↓]...[↓]]  [[↓]...[↓]]                   [[↓]...[↓]]
// LEVEL2                                  [*]...[*]   [[[↓]...[↓]]...[[↓]...[↓]]]   [[[↓]...[↓]]...[[↓]...[↓]]]
// LEVEL3		 									   [*]...[*]				     [[[[↓]...[↓]]...[[↓]...[↓]]]...[[[↓]...[↓]]...[[↓]...[↓]]]]
//																		 		     [*]..[*]

I made the recursion part a seperate method called recursion. In the getDirectBlock method, I first decide which level it is at based on blockNum, then I call the recursion method using corresponding parameters. The level indicates how many indirection it needs. If it exceeds the maximum limit of third indirection, the system will be terminated. For easier access, bnl is an int array that stores the block numbers per level, and bno is an int array that stores the block number offset per level. In the recursion part, the base case is when level is 0, where direct block could be returned. Otherwise, it followes the pointer to next level recursively until it reaches the base case.